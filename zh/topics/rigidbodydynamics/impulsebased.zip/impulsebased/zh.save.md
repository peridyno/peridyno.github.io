---
math : true
title: "基于脉冲的多体动画"
linkTitle: "4.2.1 基于脉冲的多体动画"
date: 2021-12-29
weight: 521
authors : ["luoxukun"]
description: >
  Impulse-Based Multibody Animation
---


Impulse $J$ 冲量

## Basic Theorem

- Single-Point Collision
- Multiple-Point Collision

### 1 Single-Point Collision: Theorem 6.2 (Applying Impulse to a Rigid Body)

**两个刚体**且只有**一对碰撞点**的碰撞：

<div align="center">
<img src="image-20211220155058733.png" alt="image-20211220155058733" style="zoom: 50%;" />
</div>
![](image-20211220155058733.png)


首先确立刚体的$v,w$与冲量$J$关系：
$$
\begin{aligned}
&\Delta \boldsymbol{v}=\frac{\boldsymbol{J}}{m} \\\\
&\Delta \boldsymbol{\omega}=\boldsymbol{I}^{-1}(\boldsymbol{r} \times \boldsymbol{J})
\end{aligned}
$$

然后根据刚体与碰撞点的关系：（$\gamma$可以暂时理解为时间步长）

$$
v_{\text{point}}^A\left( \gamma \right) =\omega ^A\left( \gamma \right) \times r^A+v_{\text{body}}^{A}\left( \gamma \right) 
$$


以及一对碰撞点<A,B>的关系：
$$
\boldsymbol{J}^{B}=-\boldsymbol{J}^{A}
$$
推导出**碰撞点**对相对速度的变化量与冲量关系：（根据模型分类，可以得到$\Delta \boldsymbol{u}$，即已知量）
$$
\Delta \boldsymbol{u}(\gamma)=\underbrace{\left(\left(\frac{1}{m_{A}}+\frac{1}{m_{B}}\right) \boldsymbol{1}-\left(\left(\boldsymbol{r}^{\boldsymbol{A}}\right)^{\times} \boldsymbol{I}_{A}^{-1}\left(\boldsymbol{r}^{\boldsymbol{A}}\right)^{\times}+\left(\boldsymbol{r}^{\boldsymbol{B}}\right)^{\times} \boldsymbol{I}_{B}^{-1}\left(\boldsymbol{r}^{\boldsymbol{B}}\right)^{\times}\right)\right)}_{\boldsymbol{K}} \boldsymbol{J}^{A}(\gamma) .
$$
其中，
$$
u =v^A_{point}-v^B_{point}\\
\Delta u=u(f)-u(i)
$$
$K$被称为碰撞矩阵 Collision Matrix，其中$\left(r\right)^{\times}$计算方式为：

<img src="image-20211220152649868.png" alt="image-20211220152649868" style="zoom:33%;" />
![](image-20211220152649868.png)
自此，得到**两个刚体碰撞**且只有**一对碰撞点**的计算方法。



### 2 Multiple-Point Collision

**多对刚体**且**多对碰撞点**的碰撞。

- Sequential Collision  （AKA. propagating impulses 依次碰撞）
- Simultaneous Collision （同时碰撞）

<img src="image-20211221145355053.png" alt="image-20211221145355053" style="zoom: 50%;" />
![](image-20211221145355053.png)


#### 2.1 Sequential Collision 

将Single-Point执行多次，缺点：

- 执行碰撞点顺序会影响结果
- 可能死循环

<img src="image-20211220164212276.png" alt="image-20211220164212276" style="zoom: 67%;" />
![](image-20211220164212276.png)


#### 2.2 Simultaneous Collision 

将考虑碰撞点受到**其他**碰撞点所带来的**多个冲量**的影响。

<img src="image-20211220165807057.png" alt="image-20211220165807057" style="zoom: 33%;" />
![](image-20211220165807057.png)

<img src="%E4%B8%A4%E4%B8%AA%E7%A2%B0%E6%92%9E%E7%82%B9.gif" alt="两个碰撞点" style="zoom:33%;" />
![](image-%E4%B8%A4%E4%B8%AA%E7%A2%B0%E6%92%9E%E7%82%B9.png)


以**Newton‘s Collision Law**为例子，重新描述式子：

**一些特征：**

- 不考虑摩擦
- 只考虑法向冲量和法向速度变化

**关键思路**：

<1 碰撞点**相对速度**会受多个冲量影响，故速度会大于等于原先单一冲量影响下的速度（只考虑法向速度变化故）（预谋获取$\Delta u$）
$$
u_{i_{f}} \geq-e u_{i_{i}}
$$

做一个假设：$u_{i_{f}}>-e u_{i_{i}} \Rightarrow j_{i}=0$，使得$j_i$并不会太大。（这里可能不太有准确的意义，只是一个假设）

然后同resting contact problem一样，可以整合成互补条件：
$$
0\le j_i \bot (u_{i_{f}} +e u_{i_{i}}) \ge 0
$$
<2 利用刚体与碰撞点关系衡量其他冲量对碰撞点的影响 （推导出$\Delta u$与$J$的关系）

<img src="image-20211221133337811.png" alt="image-20211221133337811" style="zoom:33%;" />
![](image-20211221133337811.png)

表示物体 $X$ 的接触点 $j$ 受冲量 $J_i$的影响，即
$
\Delta v_{ji}^{X}=u_{ji}^{X}\left( after \right) -u_{ji}^{X}\left( before \right) 
$

$$
\Delta v_{ji}^{X}=\Delta v_{i}^{X}+\Delta \omega _{i}^{X}\times r_{j}^{X}
$$

其中冲量$J_i$对物体$X$的影响：
$$
\Delta v_{i}^{X}=\pm \frac{n_i}{m_X}j_i,\,\,\,\,\Delta \omega _i^X=\pm I_{X}^{-1}\left( r_i^X\times n_i \right) j_i
$$

其中 $n_i$ 表示$\vec{J_i}$的方向

进一步推导：
$$
\begin{aligned}
	\Delta v_{ji}^{X}&=\left( \frac{n_i}{m_X}+\left( I_{X}^{-1}\left( r_{i}^{X}\times n_i \right) \right) \times r_{j}^{X} \right) j_i\\\\
	\Delta v_{ji}^{X}&=s_{ji}^{X}j_i\\
\end{aligned}
$$

累加在碰撞点$j$的所有冲量影响：
$$
\Delta v_{j}^{X}=\Delta v_{j0}^{X}+\cdots +\Delta v_{ji}^{X}+\cdots +\Delta v_{jn}^{X}
$$


计算物体$X,Y$的碰撞点 $j$ 相对速度：
$$
\Delta u=\Delta v_{j}^{X}-\Delta v_{j}^{Y}=\left( s_{j0}^{X}-s_{j0}^{Y} \right) j_0+\cdots +\left( s_{ji}^{X}-s_{ji}^{Y} \right) j_i+\cdots +\left( s_{jn}^{X}-s_{jn}^{Y} \right) j_n
$$


又因$\Delta u=u_f-u_i$，得：
$$
\begin{gathered}
u_{j}(f)=\boldsymbol{A}_{j 0} j_{0}+\cdots+\boldsymbol{A}_{j i} j_{i}+\cdots+\boldsymbol{A}_{j n} j_{n}+u_{j}(i) \\\\
\boldsymbol{A}_{j i}=\left(\boldsymbol{s}_{j i}^{X}-\boldsymbol{s}_{j i}^{Y}\right) \cdot \boldsymbol{n}_{j}
\end{gathered}
$$



**求解**：

整理公式得LCP（二次优化问题，需要使用一些求解器）
$$
0\le J \bot (AJ + (1+e) u_{i}) \ge 0
$$


## Collision Laws

一些模型例子，主要是描述 $\Delta \boldsymbol{u}$ 的含义。

- Algebraic Collision Laws 

- Incremental Collision Laws 

- Full Deformation Collision Laws 

- Compliant Contact Model Collision Laws

  

### Examples of Algebraic Collision Laws 

- Newton’s collision law
- A two-parameter frictional law
- A frictional version of Newton’s collision law

#### Newton‘s Collision Law

**特征：**

- 不考虑摩擦
- 采用弹性碰撞

**关键假设：**

<1 冲量与碰撞平面法线**平行**
$$
\boldsymbol{J}=j\boldsymbol{n}
$$
<2 **相对速度**弹性**恢复** （时间$i\longrightarrow f$，恢复系数coefficient of restitution $e$）
$$
u_{n}\left(\gamma_{f}\right)=-e u_{n}\left(\gamma_{i}\right)
$$
进一步推导，$u_i \longrightarrow \Delta u$
$$
\begin{aligned}
\Delta \boldsymbol{u} \cdot \boldsymbol{n} &=u_{n}\left(\gamma_{f}\right)-u_{n}\left(\gamma_{i}\right) \\\\
\Delta \boldsymbol{u} \cdot \boldsymbol{n} &=-e u_{n}\left(\gamma_{i}\right)-u_{n}\left(\gamma_{i}\right) \\\\
\Delta \boldsymbol{u} \cdot \boldsymbol{n} &=-(1+e) \boldsymbol{u}_{i} \cdot \boldsymbol{n}
\end{aligned}
$$
进一步推导，$\Delta u \longrightarrow j$
$$
\begin{aligned}
\Delta \boldsymbol{u} \cdot \boldsymbol{n} &=(\boldsymbol{K} j \boldsymbol{n}) \cdot \boldsymbol{n}, \\\\
\Delta \boldsymbol{u} \cdot \boldsymbol{n} &=j(\boldsymbol{n}^{T} \boldsymbol{K} \boldsymbol{n}),
\end{aligned}
$$

$$
j=\frac{-(1+e) \boldsymbol{u}_{i} \cdot \boldsymbol{n}}{\boldsymbol{n}^{T} \boldsymbol{K} \boldsymbol{n}}
$$



## 计算流程

```
Collision Detection
Compute the wanted collision point's vel: u_i
Compute K
Compute J
Compute \Delta v, \Delta w.
Update Position x.
```



### Some knowledge





#### Collision Matrix $K$

$K$矩阵有一些性质：



#### Contact Normal $\vec{n}$



#### 推导技巧

- $(An)\cdot n =n^{T}An$ 







### 参考资料

- Physically Based Animation 【Chapter6 Impulse-Based Multibody Animation】
- Analytical Methods for Dynamic Simulation of Non-penetrating Rigid Bodies, Baraff, SIGGRAPH ’89

